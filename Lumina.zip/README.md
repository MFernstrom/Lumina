![Lumina](media/lumina.png)  
[![Chat on Discord](https://img.shields.io/discord/754884471324672040?style=for-the-badge)](https://discord.gg/tPWjMwK) [![Twitter Follow](https://img.shields.io/twitter/follow/tinyBigGAMES?style=for-the-badge)](https://twitter.com/tinyBigGAMES)
<div align="center">

### Local Generative AI

</div>

### Overview 📝

**Lumina** is derived from the Latin word "lumen," meaning "light." It often symbolizes brightness, enlightenment, or illumination. The name can evoke ideas of clarity, insight, and discovery, making it a fitting name for a project related to **generative AI**, where the focus is on bringing new ideas, creativity, and understanding to light. It carries connotations of guiding or illuminating knowledge and innovation.

*(coming soon)*
